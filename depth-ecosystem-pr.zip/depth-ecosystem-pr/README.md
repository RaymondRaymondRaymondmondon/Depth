# Depth: ecosystem/parkour expansion — PR contents

GitHub PR: https://github.com/RaymondRaymondRaymondmondon/Depth/pull/3
Branch: `claude/abyss-completion` -> `master`

## What's in this zip

- `full.diff` — the complete unified diff for the PR (`git diff origin/master...HEAD`). Apply with
  `git apply full.diff` from a clean checkout of `master`, or just read it.
- `commits.txt` — the 7 commits in this PR, oldest first, one line each.
- `changed-files/` — every file touched by this PR, at its final state on the branch (not a diff — the
  whole file, so you can read any of them without applying the patch). Same relative paths as the repo:
  `changed-files/src/abyss.cpp` is `src/abyss.cpp`, `changed-files/ECOSYSTEM_BESTIARY.md` is the repo-root
  file, etc.

## What was built, in plain terms

Three pieces, built against the user's full seven-biome ecosystem brief (persisted verbatim in
`ECOSYSTEM_BESTIARY.md`, since it had to be re-supplied once mid-project — it's now safe in the repo).

### 1. The Open Abyss (new biome)

A fully 3D vertical-descent dive, separate from the existing 2D platformer's engine. All 10 species from the
brief, Water Dash / Hydro-Glide movement matching the brief's exact numbers (0.3s dash, 20% stamina cost,
65% drag reduction while gliding), sculpted set-piece zones (thermal vents, a stinging-colony maze, a
near-weightless brine pool, a "bowling lane" of falling Isopods), a stamina-based hazard model (every hit
costs stamina + a knockback + a brief invincibility window — nothing kills you outright except running out
of stamina), visual polish (marine snow, a pressure-distortion shader), and a real entry point from the
Periscope with save/load for best depth reached.

Of its 10 species, 7 can actually hit the player (Giant Isopod, Gulper Eel, Vampire Squid, Trench Worm, Brine
Slug, Siphonophore, Leviathan); Glass Sponge is a foothold that punishes a hard landing; Bioluminescent
Plankton is a pure visual "tell"; Hatchetfish are pure decoration.

### 2. The Hull (retrofit)

The two pre-existing enemies (crabs, eels) were promoted to "Barnacle Crab" / "Moray Eel" with a rolled
personality system (aggression/bravery/energy/curiosity), so the same species reads differently run to run.
The other 7 species from the brief's Hull chain — Cleaner Shrimp, Camouflage Octopus, Pufferfish, Hull-Leech,
Stinging Anemone, Hermit Crab, Brittle-Star — were added on top, with the real causal chain between them:
a Shrimp draws an Octopus into ambush; a Crab pinches an Octopus that lands on its bed, or the player just
bumps one, either way spraying an ink cloud; a Pufferfish caught in the ink panics and puffs up (this is the
one new species that's an actual hazard — touching a puffed Pufferfish kills you, same as the crabs/eels);
a puffed Pufferfish knocks a dormant Hull-Leech loose to drift; a Stinging Anemone catches a drifting Leech;
a Hermit Crab scavenges the scraps; Brittle-Star mats break underfoot after a moment.

A real, pre-existing bug was found and fixed along the way: eels (and Pirate Ship parakeets) had been
complete dead code since an earlier generator rewrite — the only code that ever placed them lived in a
branch that could never run where those tiles are actually built. The game's own how-to-play text had been
telling players about "leaping eels" in a Hull that could never contain one. Fixed for the Hull; the Pirate
Ship's parakeets have the same bug and are explicitly left out of scope for this PR.

### 3. The Pipes (retrofit)

The real 10-species chain from the brief: Dust Moths fly to the duct's surviving light leaks; Water-Spiders
catch one in a web at a fixed post; Centipedes eat a caught Moth, freeing it; Blind Pipe-Rats hunt a feeding
Centipede by proximity and, if aggressive, bite the pipe on contact; Rust-Mites swarm out at a bite to feed
on the flakes, and a swarming Mite curls up any Pillbug it brushes; a curled Pillbug rolls, and a rolling one
scares off a hunting Scavenger Mouse; an aggressive Cockroach near a Mouse picks a fight; a fight near a
Glow-Beetle makes it flash; a flash near a Cave Cricket panics it into a stampede that cascades Cricket to
Cricket as it jumps wildly through the duct.

Unlike every other biome, the Pipes are built so **nothing in this chain ever reacts to the diver, in either
direction** — per the brief's own line for this one biome ("entities ignore the player; all hazards stem from
systemic chaos and collateral physics") and the game's pre-existing design rule that the Pipes have no
enemies. It's verified explicitly: the diver can be swept across an entire generated level and no entity's
position ever moves in response.

## Verification

All of the following pass (`depth.exe <flag>`, headless, no window needed):
`--verify`, `--verify-abyss`, `--verify-critters`, `--verify-hull-life`, `--verify-hull-ecosystem` (new),
`--verify-pipe-ecosystem` (new). `--flats-sim` (an unrelated system) was spot-checked unaffected. The Hull
and the Pipes were screenshotted after each change and reviewed for visual regressions.

## What's deliberately not in this PR

- The Pirate Ship's own 10-species retrofit (and its likely-identical eel/parakeet dead-code bug).
- The four brand-new parkour-only biomes from the brief (Island, Cave, Weeds, Atlantis) — these are additions
  to the parkour section only and must never touch the existing turn-based expedition locations of the same
  names, per the user's explicit instruction.
